# Assignment 2 - 🔄 Sets & Traversals

- 💯 **Worth**: 6.5%
- 📅 **Due**: Posted on Moodle
- 🙅🏽‍ **Penalty**: Late submissions lose 10% per day to a maximum of 3 days. Nothing is accepted after 3 days and a grade of 0% will be given.

## 🎯 Objectives

- **Implement** a set collection of unique elements in an array.
- **Generalize** the data type used by the set using generics.
- **Traverse** the set's non-sequential elements in an array.

## 🎴 Sets

A _set_ is a collection of distinct elements.

> This README contains several math blocks that are not renderable by IntelliJ. To view the math blocks properly, please view this README on GitHub.

$$
\{2,3,5,7\} \hspace{0.5cm}
\{\texttt{'a'}, \texttt{'b'}, \texttt{'c'}\} \hspace{0.5cm}
\{\texttt{"aardvark"}, \texttt{"aardwolf"}, \texttt{"albatross"}\}
$$

We will create a set data structure, but restrict ourselves to only sets whose elements have _unique_ identifiers (IDs).

The sets you will represent here are similar to the sets you have studied in mathematics, but with one important difference: **the set contains only elements of the same datatype**.

### Contains

The fundamental operation _contains_ (a.k.a.: member, usually denoted by $\in$) on a set is to tell if an element is contained within it:

$$
a \in \{a, b, c\} \hspace{1cm} c \not\in \{a, b \}
$$

### Contains All

Determine if every element of a set $A$ is also in a second set $B$, that is, $A$ is entirely in $B$ (a.k.a. subset). This is usually written as $A \subseteq B$. For example:

$$
\{a, c\} \subseteq \{a, b, c, d\}  \hspace{1cm}  \{b, d\} \not\subseteq \{a, b, c\}
$$

A more formal definition of subset is: for all $x$, if $x \in A$ then $x \in B$.

### Add

Sets are built using an operation for adding an element to an existing set. If we have a set $\{a,b\}$, then $\textbf{add}(c)$ would yield $\{a,b,c\}$. Add should behave like the traditional set _union_ operation $\cup$, in that adding a duplicate to a set would leave the set unchanged. Ex:

$$
\{a,b,c\} \cup \{a\}  = \{a,b,c\}
$$

### Remove

An element can be removed from a sorted set using the remove operation. If we have a set $\{a,b,c\}$, then $\textbf{remove}(c)$ would yield $\{a, b\}$. Remove should behave like the traditional set _difference_ operation $-$, in that removing an element not in the original set results in the set unchanged. Ex:

$$
\{ a, b, c \} - \{ d \} = \{ a, b, c \}
$$

### Size

Number of elements of the set (a.k.a. cardinality). This is usually written as $|A|$.

### Empty/Full

Determine if the set is empty ($\{\}$) or full. A set is full if there is insufficient space to store additional elements.

### To String

Operations to get a string representation of a set (see API).

### Set API

This specification uses a type parameter `T`.

| Signature     | `boolean contains(T element)`                                                      |
| ------------- | ---------------------------------------------------------------------------------- |
| Description   | Determine if the set contains a specific element.                                  |
| Preconditions | None.                                                                              |
| Mutator       | No.                                                                                |
| Returns       | `true` if an element is found in the set that equals `element`, `false` otherwise. |

| Signature     | `boolean containsAll(Set<T> rhs)`                                                                                             |
| ------------- | ----------------------------------------------------------------------------------------------------------------------------- |
| Description   | Determine if the set contains all the elements of the provided set, or, that the provided set is a subset of the current set. |
| Preconditions | None.                                                                                                                         |
| Mutator       | No.                                                                                                                           |
| Returns       | `true` if all the elements of `rhs` are in the current set, `false` otherwise. <br> `true` if `rhs` is empty.                 |

| Signature     | `boolean add(T element)`                                                                                                                                         |
| ------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Description   | Add an element into the set. If there is no element in the set that equals `element`, then the element is inserted into the set. Otherwise the set is unchanged. |
| Preconditions | None.                                                                                                                                                            |
| Mutator       | Yes.                                                                                                                                                             |
| Returns       | `true` if the element is added to the set, `false` otherwise.                                                                                                    |
|               |                                                                                                                                                                  |

| Signature     | `boolean remove(T element)`                                                                                                                             |
| ------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Description   | Remove an element from the set. If there is an element in the set equal to `element`, then it is removed from the set. Otherwise, the set is unchanged. |
| Preconditions | None.                                                                                                                                                   |
| Mutator       | No.                                                                                                                                                     |
| Returns       | `true` if the element is removed from the set, `false` otherwise.                                                                                       |

| Signature     | `int size()`                                 |
| ------------- | -------------------------------------------- |
| Description   | Determine the number of elements in the set. |
| Preconditions | None.                                        |
| Mutator       | No.                                          |
| Returns       | The number of elements in the set.           |

| Signature     | `boolean isEmpty()`                            |
| ------------- | ---------------------------------------------- |
| Description   | Determine if the set is empty.                 |
| Preconditions | None.                                          |
| Mutator       | No.                                            |
| Returns       | `true` if the set is empty, `false` otherwise. |

| Signature     | `boolean isFull()`                            |
| ------------- | --------------------------------------------- |
| Description   | Determines if the set is full.                |
| Preconditions | None.                                         |
| Mutator       | No.                                           |
| Returns       | `true` if the set is full, `false` otherwise. |

| Signature     | `String toString()`                                                                                                                                              |
| ------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Description   | Get a `String` representation of the set.                                                                                                                        |
| Preconditions | None.                                                                                                                                                            |
| Mutator       | No.                                                                                                                                                              |
| Returns       | A `String` representation of the set, consisting of: <br> -   a `{`, <br> -   the `String` representations of the elements, comma-separated, and <br> -   a `}`. |

## ✈️ Traversals

A _traversal_ is a series of operations that enable a visiting of each of the elements in the collection. For example the traversal of $\{ "a", "b", "c" \}$ will be: first "a", then "b", then finally "c".

The traversal operation is broken down into 3 sub-operations: `reset`, `hasNext` and `next`. Resetting restarts the traversal from the beginning, for example, after a previous traversal. `next` gives the subsequent element in the traversal, and `hasNext` indicates if there is a subsequent element to visit.

### Traversable API

Traversals are used to "loop" over the data type. For example, if `set` is a traversable collection of strings, then we can write the following:

```java
set.reset();

while(set.hasNext()) {
    String s = set.next();

    System.out.println(s);
}
```

| Signature     | `void reset()`                                                                                                                                            |
| ------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Description   | Initialize a traversal. If there are elements, the traversal cursor is positioned on the first element. Otherwise, the traversal is complete (trivially). |
| Preconditions | None.                                                                                                                                                     |
| Mutator       | Yes, but only the traversal portion.                                                                                                                      |
| Returns       | None.                                                                                                                                                     |

| Signature     | `boolean hasNext()`                                                                                                                          |
| ------------- | -------------------------------------------------------------------------------------------------------------------------------------------- |
| Description   | Determine if a traversal can continue.                                                                                                       |
| Preconditions | The traversal has been initialized and no modifications (ex: **add** or **remove** operations) have been performed since the initialization. |
| Mutator       | No.                                                                                                                                          |
| Returns       | Returns `true` is there are elements left in the traversal, `false` otherwise.                                                               |

| Signature     | `T next()`                                                                                                                                                                                                                                 |
| ------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| Description   | If there is a next element, the traversal cursor is advanced to that element and that element is returned. <br> At the end of the traversal, the cursor is _undefined_, meaning that there is no longer a subsequent element to travel to. |
| Preconditions | The traversal has been initialized and no modifications (**add** or **remove** operations) have been performed since the initialization. <br> The traversal still has at least one element left.                                           |
| Mutator       | Yes, but only the traversal portion.                                                                                                                                                                                                       |
| Returns       | The next element in the traversal.                                                                                                                                                                                                         |

## 📝 Requirements

Implement the `Set` and `Traversable` APIs using a Java **array** in a class called `IdSet<T>`. Instead of storing items in adjacent cells (next to each), we will store them in the position indicated by their ID, outlined here.

### IDs and Array Indices

We will limit the type of elements we can store in our set to only those with integer IDs, which we'll call _identifiable_. We can enforce this restriction by only allowing elements whose class implements an interface called `Identifiable`:

```java
/**
 * Represents an object with an integer ID.
 */
public interface Identifiable {

    /**
     * Get the ID of the identifiable.
     * @return The ID of the identifiable
     */
    int id();
}
```

Each identifiable object has a method called `id()` that, when implemented correctly, will give a unique integer for that object. These will be used to compute the array location used to store the element.

For example, if storing a set containing elements $e_{\mathsf{id}=3}$, $e_{\mathsf{id}=4}$, $e_{\mathsf{id}=5}$ and $e_{\mathsf{id}=8}$ like this:

![Sample set with low ids](images/example1.svg)

Since IDs are arbitrary integers, they can be large and very far from each other in the array. Think about your student IDs! We can "squeeze" any ID into an array position by applying the modulus operator: `pos = id % elements.length`.

For example, if we have a set containing elements $e_{\mathsf{id}=12343}$, $e_{\mathsf{id}=11314}$, $e_{\mathsf{id}=13345}$ and $e_{\mathsf{id}=12128}$

![Sample set with arbitrary ids](images/example2.svg)

### Collisions

Unfortunately, it is possible that two elements will have the same location within the range of indices `[0, elements.length - 1]`. When this happens we call it a _collision_. We will handle collisions in the following way: consider the array a "circular" array, proceed clockwise (increasing index) until you find an empty cell, and place the element in that cell.

Example 1: If we have the set:

![Collision example 1](images/collision1.svg)

and we add $e_{\mathsf{id}=15}$, we will get a collision in cell 5, so this new element will end up in cell 6:

![Collision example 1](images/collision2.svg)

and then if we add $e_{\mathsf{id}=25}$, we will get a collision in cells 5, 6 and 7, so it will end up in cell 8:

![Collision example 1](images/collision3.svg)

Example 2: A collision can happen at the end of the array. Again, if we have set:

![Collision example 2](images/collision4.svg)

and we add element $e_{\mathsf{id}=19}$, we "wrap" around and place it at the beginning of the array:

![Collision example 2](images/collision5.svg)

### Removing Elements

Removing elements is now a bit more complicated. Removing elements will produce "holes" that will break your other set methods, like `contains()`, unless we're careful.

For example, if we have:

![Remove example](images/remove1.svg)

and remove $e_{\mathsf{id}=15}$ by making it empty again:

![Remove example](images/remove2.svg)

Finding $e_{\mathsf{id}=25}$ won't work anymore!

We will solve this problem by adding _tombstones_ for removed elements. A tombstone will be left in cells where element has been removed:

![Remove example](images/remove3.svg)

When searching for an element, tombstones should be passed over to find elements on the other side!

Tombstones might eventually be replaced when adding a new element to the set. For example, in the previous set, if we add the element $e_{\mathsf{id}=35}$, then the tombstone will be filled:

![Remove example](images/remove4.svg)

### Cleaning Up

Eventually, if we have lots of tombstones, they will be in the way when searching for elements. Implement a method called `clean()` that will simplify the space by removing all tombstones.

For example, cleaning the tombstones from:

![Clean example 1](images/clean1.svg)

will result in:

![Clean example 2](images/clean2.svg)

## 🧪 Starter and Unit Tests

Use the provided starter to implement the class `IdSet<T>` as it is setup. It uses the class `Cell<T>` and the enum `State` to store information about the contents of the array.

The unit tests in `TestIdSet` are provided to check your progress, but **do not guarantee that your implementation is entirely correct**.

## 🌿 Git

1. Run `git status` to see a list of files that have changed and are ready to be staged.
2. Run `git add .` to stage all the modified files to be committed. Alternatively, you can add specific files like this: `git add src/Set.java`.
3. Run `git commit -m "A descriptive message here."` (including the quotes) to commit all the files that were just staged.
4. Run `git push` to push the commit(s) up to GitHub.

It is very important that you commit frequently because:

- If you end up breaking your code, it is easy to revert back to a previous commit and start over.
- It provides a useful log of your work so that you (and your teammates if/when you're on a team) can keep track of the work that was done.

## 📥 Submission

Once you've made your final `git push` to GitHub, here's what you have to do to submit:

1. Retrieve the ID code (SHA) associated with the commit. On GitHub repo page, browse your commits:

   ![Submission 1](./images/1-submission.png)

2. Choose the commit you want to submit:

   ![Submission 2](./images/2-submission.png)

3. Copy the commit ID (SHA)

   ![Submission 3](./images/3-submission.png)

4. Paste this commit ID to the submission dropbox on Moodle.

### Style

Your program should be clear and well commented. It must follow the [420-4P6 Style Checklist](https://moodle.johnabbott.qc.ca/mod/resource/view.php?id=9791).
