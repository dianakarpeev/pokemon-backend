import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * Tests for IdSet implementation of set.
 *
 * @version 3 Added contains all and traversal tests.
 */
public class TestIdSet {

    /**
     * A read-only set used only for testing.
     * @param <T>
     */
    private static class StaticSet<T> implements Set<T> {

        private final T[] elements;
        private int traversal;

        public StaticSet(T[] elements) {
            this.elements = elements;
        }

        @Override
        public boolean contains(T elem) {
            for (T e : elements)
                if(e.equals(elem))
                    return true;
            return false;
        }

        @Override
        public boolean containsAll(Set<T> rhs) {
            throw new RuntimeException("Unimplemented.");
        }

        @Override
        public boolean add(T elem) {
            throw new RuntimeException("Unimplemented.");
        }

        @Override
        public boolean remove(T elem) {
            throw new RuntimeException("Unimplemented.");
        }

        @Override
        public int size() {
            return elements.length;
        }

        @Override
        public boolean isEmpty() {
            return false;
        }

        @Override
        public boolean isFull() {
            return true;
        }

        @Override
        public void reset() {
            traversal = -1;
        }

        @Override
        public boolean hasNext() {
            return traversal < elements.length - 1;
        }

        @Override
        public T next() {
            return elements[++traversal];
        }
    }

    private IdSet<Record> set;

    @BeforeEach
    public void setUp() {
        set = new IdSet<>(10);
        set.add(new Record(3, "a"));
        set.add(new Record(8, "b"));
        set.add(new Record(9, "c"));
    }

    @Test
    public void testAddNoCollision() {
        assertTrue(set.add(new Record(0, "d")));
        assertTrue(set.add(new Record(1, "e")));
        assertTrue(set.add(new Record(7, "f")));
    }

    @Test
    public void testAddDuplicate() {
        assertFalse(set.add(new Record(3, "d")));
        assertFalse(set.add(new Record(8, "e")));
        assertFalse(set.add(new Record(9, "f")));
    }

    @Test
    public void testSizeAndEmpty() {
        assertEquals(3, set.size());
        assertFalse(set.isEmpty());

        set.add(new Record(1, "d"));
        assertEquals(4, set.size());

        IdSet<Record> set2 = new IdSet<>(10);
        assertEquals(0, set2.size());
        assertTrue(set2.isEmpty());
    }

    @Test
    public void testContains() {
        assertTrue(set.contains(new Record(3)));
        assertTrue(set.contains(new Record(8)));
        assertTrue(set.contains(new Record(9)));

        assertFalse(set.contains(new Record(2)));
        assertFalse(set.contains(new Record(4)));
        assertFalse(set.contains(new Record(7)));
        assertFalse(set.contains(new Record(10)));
    }

    @Test
    public void testContainsOnFullSet() {
        set.add(new Record(0, "d"));
        set.add(new Record(2, "e"));
        set.add(new Record(4, "f"));
        set.add(new Record(5, "g"));
        set.add(new Record(6, "h"));
        set.add(new Record(7, "i"));
        set.add(new Record(1, "j"));

        assertTrue(set.contains(new Record(7)));
        assertFalse(set.contains(new Record(10)));
    }

    @Test
    public void testAddCollision() {
        assertTrue(set.add(new Record(13, "d")));
        assertTrue(set.add(new Record(23, "e")));
        assertTrue(set.add(new Record(14, "f")));
    }

    @Test
    public void testAddCollisionContains() {
        // add some collisions
        set.add(new Record(13, "d"));
        set.add(new Record(23, "e"));
        set.add(new Record(14, "f"));

        assertTrue(set.contains(new Record(13)));
        assertTrue(set.contains(new Record(23)));
        assertTrue(set.contains(new Record(14)));

        assertFalse(set.contains(new Record(33)));
        assertFalse(set.contains(new Record(24)));
    }

    @Test
    public void testFullSetNoCollision() {
        assertFalse(set.isFull());

        set.add(new Record(0, "d"));
        set.add(new Record(1, "e"));
        set.add(new Record(2, "f"));
        set.add(new Record(4, "g"));
        set.add(new Record(5, "h"));
        set.add(new Record(6, "i"));
        set.add(new Record(7, "j"));

        assertTrue(set.isFull());
    }

    @Test
    public void testFullSetCollision() {
        assertFalse(set.isFull());

        set.add(new Record(0, "d"));
        set.add(new Record(10, "e"));
        set.add(new Record(20, "f"));
        set.add(new Record(30, "g"));
        set.add(new Record(40, "h"));
        set.add(new Record(50, "i"));
        set.add(new Record(60, "j"));

        assertTrue(set.isFull());
    }

    @Test
    public void testRemoveNoCollisions() {
        assertTrue(set.remove(new Record(3, "d")));
        assertFalse(set.contains(new Record(3)));
        assertTrue(set.remove(new Record(8, "e")));
        assertFalse(set.contains(new Record(8)));
        assertTrue(set.remove(new Record(9, "f")));
        assertFalse(set.contains(new Record(9)));
    }

    @Test
    public void testRemoveNonMembers() {
        assertFalse(set.remove(new Record(0)));
        assertFalse(set.remove(new Record(1)));
        assertFalse(set.remove(new Record(7)));
    }

    @Test
    public void testRemoveCollision() {
        set.add(new Record(13, "d"));
        set.add(new Record(23, "e"));

        assertTrue(set.remove(new Record(23)));
        assertFalse(set.contains(new Record(23)));

        assertTrue(set.remove(new Record(13)));
        assertFalse(set.contains(new Record(13)));
    }

    @Test
    public void testRemoveCollisionGap() {
        set.add(new Record(13, "d"));
        set.add(new Record(23, "e"));

        assertTrue(set.remove(new Record(13)));
        assertFalse(set.contains(new Record(13)));
        assertTrue(set.contains(new Record(23)));
    }

    @Test
    public void testRemoveAddCollisionGap() {
        set.add(new Record(13, "d"));
        set.add(new Record(23, "e"));
        set.remove(new Record(13));
        set.add(new Record(33, "f"));
        assertTrue(set.contains(new Record(23)));
    }

    @Test
    public void testFullSetAfterRemove() {
        set.remove(new Record(3));
        set.remove(new Record(8));
        set.add(new Record(0, "d"));
        set.add(new Record(10, "e"));
        set.add(new Record(20, "f"));
        set.add(new Record(30, "g"));
        set.add(new Record(40, "h"));
        set.add(new Record(50, "i"));
        set.add(new Record(60, "j"));
        set.add(new Record(70, "j"));
        set.add(new Record(80, "j"));

        assertTrue(set.isFull());
    }

    @Test
    public void testContainsAll() {
        set.add(new Record(13));
        set.add(new Record(5));

        Set<Record> subset = new StaticSet<>(new Record[] {
                new Record(8),
                new Record(13),
                new Record(5)
        });

        assertTrue(set.containsAll(subset));
    }

    @Test
    public void testContainsAllEmptySet() {
        // empty set is subset of any sets
        StaticSet<Record> empty = new StaticSet<>(new Record[0]);
        assertTrue(set.containsAll(empty));
    }

    @Test
    public void testEqualSets() {
        // equal sets are subsets of each other
        StaticSet<Record> same = new StaticSet<>(new Record[] {
                new Record(9),
                new Record(3),
                new Record(8)
        });

        assertTrue(set.containsAll(same));
    }

    // This test assumes that the traversal will visit elements in order they appear in the cells array.
    @Test
    public void testCleanUp() {
        set.add(new Record(13, "d"));
        set.add(new Record(23, "e"));
        set.add(new Record(33, "f"));
        set.add(new Record(43, "g"));
        set.add(new Record(1, "h"));
        set.add(new Record(18, "j"));

        set.remove(new Record(13));
        set.remove(new Record(33));
        set.remove(new Record(1));

        set.clean();

        int[] ids = new int[] {9, 3, 23, 43, 18, 8};
        set.reset();
        for(int id : ids) {
            assertTrue(set.hasNext());
            assertEquals(new Record(id), set.next());
        }
        assertFalse(set.hasNext());
    }

    @Test
    public void testToString() {
        set.add(new Record(13, "d"));
        set.add(new Record(23, "e"));

        String str = set.toString();
        System.out.println(str);
        assertTrue(str.startsWith("{"));
        assertTrue(str.endsWith("}"));

        // using string contains since the elements could be in a different order
        // and it's still correct.
        assertTrue(str.contains("(3,a)"));
        assertTrue(str.contains("(13,d)"));
        assertTrue(str.contains("(23,e)"));
        assertTrue(str.contains("(8,b)"));
        assertTrue(str.contains("(9,c)"));
    }

    // This test assumes that the traversal will visit elements in order they appear in the cells array.
    @Test
    public void testTraversal() {
        set.add(new Record(13));
        set.add(new Record(23));
        set.remove(new Record(13));
        set.add(new Record(19));

        int[] ids = new int[] { 19, 3, 23, 8, 9 };
        set.reset();
        for(int id : ids) {
            assertTrue(set.hasNext());
            assertEquals(new Record(id), set.next());
        }
        assertFalse(set.hasNext());
    }

    @Test
    public void testTraversalWithoutError() {
        set.reset();
        try {
            while (set.hasNext()) {
                set.next();
            }
        }
        catch (Exception e) {
            fail(e.getMessage());
        }
    }

    @Test
    public void testTraversalEmptySet() {
        IdSet<Record> set = new IdSet<>(10);

        set.reset();

        assertFalse(set.hasNext());
    }

    @Test
    public void testAddDuringTraversal() {
        set.reset();
        set.next();
        set.add(new Record(6, "d"));

        assertThrows(TraversalException.class, () -> set.next());
    }

    @Test
    public void testAddRemoveDuringTraversal() {
        set.reset();
        set.next();
        set.add(new Record(6, "d"));
        set.remove(new Record(6));

        assertThrows(TraversalException.class, () -> set.next());
    }

    @Test
    public void testCallNextOnCompletedTraversal() {
        set.reset();

        while(set.hasNext()) {
            set.next();
        }

        assertThrows(TraversalException.class, () -> set.next());
    }

    @Test
    public void testAddAfterAbandonedTraversal() {
        try {
            set.reset();
            set.next();
            set.next();
            set.add(new Record(6, "d"));
        }
        catch (Exception e) {
            fail(e.getMessage());
        }
    }

}
