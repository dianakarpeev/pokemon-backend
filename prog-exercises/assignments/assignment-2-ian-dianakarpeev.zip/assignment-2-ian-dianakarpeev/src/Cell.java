/**
 * Storage space for a single set element with the state of the cell.
 * @param <T>
 */
class Cell<T> {

    /**
     * The three states of the cell.
     */
    public enum State { EMPTY, OCCUPIED, TOMBSTONE }

    // fields
    private State state;
    private T element;

    /**
     * Create an empty cell.
     */
    public Cell() {
        state = State.EMPTY;
    }

    /**
     * Create an occupied cell.
     * @param element
     */
    public Cell(T element) {
        state = State.OCCUPIED;
        this.element = element;
    }

    public State getState() {
        return state;
    }

    public void setState(State state) {
        this.state = state;
    }

    public T getElement() {
        return element;
    }

    public void setElement(T element) {
        this.element = element;
    }

    @Override
    public String toString() {
        return switch (state) {
            case EMPTY -> "E";
            case OCCUPIED -> element.toString();
            case TOMBSTONE -> "T";
        };
    }

}
