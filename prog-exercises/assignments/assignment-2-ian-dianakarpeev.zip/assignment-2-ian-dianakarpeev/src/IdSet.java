public class IdSet<T extends Identifiable> implements Set<T> {

    private Cell<T>[] cells;
    private int cursor;
    private int size;

    /**
     * Creates and initializes a new Cell array.
     * @param capacity array size
     */
    public IdSet(int capacity) {
        this.cells = new Cell[capacity];

        for(int i = 0; i < capacity; i++)
            cells[i] = new Cell<>();

        this.size = 0;
        this.cursor = -1;
    }

    //#region Set operation methods
    /**
     * Determine if the set contains a specific element.
     * @param elem the element to find in the set.
     * @preconditions None.
     * @return true if the element is in the set, false otherwise.
     */
    public boolean contains(T elem){
        if (isEmpty())
            return false;

        reset();
        while (hasNext()){
            T nextElement = next();
            if (nextElement != null && nextElement.id() == elem.id())
                return true;
        }
        return false;
    }

    /**
     * Determine if the set contains all the elements of the provided set, or, that the provided
     * set is a subset of the current set.
     * @param rhs the set of elements to find in the current set.
     * @preconditions None.
     * @return true if the elements are all in the set, false otherwise.
     */
    public boolean containsAll(Set<T> rhs){
        while(rhs.hasNext()){
            if (!contains(rhs.next()))
                return false;
        }
        return true;
    }

    /**
     * Add an element into the set.
     * @param elem the element to add to the set.
     * @preconditions The  set is not full.
     * @postconditions If there is no element in the  set that equals `element`, then the element is inserted
     * into the  set, otherwise the set is unchanged
     * @return The method returns `true` if the element is added to the set, and `false` otherwise.
     */
    public boolean add(T elem) {
        if (isFull() || contains(elem))
            return false;

        int pos = mod(elem.id(), cells.length);

        while(cells[pos].getState() == Cell.State.OCCUPIED)
            pos = mod(pos + 1, cells.length);

        cells[pos].setElement(elem);
        cells[pos].setState(Cell.State.OCCUPIED);
        size++;
        return true;
    }

    /**
     * Remove an element from the set.
     * @param elem the element to remove from the set.
     * @preconditions None.
     * @postconditions If there is an element in the  set equal to `element`, then it is removed from the set.
     * Otherwise, the  set is unchanged.
     * @return The method returns `true` if the element is added to the set, and `false` otherwise.
     */
    public boolean remove(T elem){
        if (isEmpty() || !contains(elem))
            return false;

        reset();
        while (hasNext()){
            T nextElement = next();
            if (nextElement != null && nextElement.id() == elem.id()){
                int index = cursor;
                cells[index].setState(Cell.State.TOMBSTONE);
                size--;
                return true;
            }
        }
        return false;
    }

    /**
     * Determine the number of elements in the  set.
     * @preconditions None.
     * @return the number of elements in the set.
     */
    public int size(){
        return size;
    }

    /**
     * Determine if the  set is empty.
     * @preconditions None.
     * @return `true` if the  set is empty, `false` otherwise.
     */
    public boolean isEmpty(){
        return size == 0;
    }

    /**
     * Determines if the set is full.
     * @preconditions None.
     * @return `true` if the  set is full, `false` otherwise.
     */
    public boolean isFull(){
        return size == cells.length;
    }

    /**
     * Compute x modulo m.
     * @param x The value.
     * @param m The modulus.
     * @return The value of x modulo m, which will always be positive.
     */
    private static int mod(int x, int m) {
        if (x >= 0)
            return x % m;
        else
            return m + (x % m);
    }

    /**
     * Get a String representation of the set.
     * @preconditions None.
     * @return A String representation of the set, consisting of:
     *          - a {,
     *          - the String representations of the elements, comma-separated, and
     *          - a }.
     */
    public String toString(){
        StringBuilder sb = new StringBuilder();
        sb.append("{");

        this.reset();
        while(this.hasNext()){
            T element = next();
            if (element != null) {
                sb.append(element);
                sb.append(", ");
            }
        }

        sb.append("}");
        return sb.toString();
    }

    //#endregion

    //#region traversable methods
    @Override
    public void reset() {
        this.cursor = 0;
    }

    @Override
    public boolean hasNext() {
        return this.cursor != cells.length - 1 && !isEmpty();
    }

    @Override
    public T next() {
        if (cursor == cells.length - 1) {
            throw new TraversalException();
        }

        T element = cells[cursor].getElement();
        this.cursor = mod(cursor + 1, cells.length);
        return element;
    }

    public void clean() {
        if (isEmpty())
            return;

        reset();
        while (hasNext()){
            T element = next();
            if (element != null && element.toString().equals("T")){
                cells[cursor] = new Cell<>();
            }
        }
    }
    //#endregion
}
