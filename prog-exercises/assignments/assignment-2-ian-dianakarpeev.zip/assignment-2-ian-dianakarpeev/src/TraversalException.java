/**
 * Created by ian on 15-02-06.
 */
public class TraversalException extends RuntimeException {

    public TraversalException() {
    }

    public TraversalException(String message) {
        super(message);
    }
}
