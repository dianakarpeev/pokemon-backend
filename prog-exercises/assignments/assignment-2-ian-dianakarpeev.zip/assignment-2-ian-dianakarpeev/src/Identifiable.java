/**
 * Represents an object with an integer ID.
 */
public interface Identifiable {

    /**
     * Get the ID of the identifiable.
     * @return The ID of the identifiable
     */
    int id();
}
