public class Record implements Identifiable {

    private int id;
    private String title;
    private String description;

    public Record(int id) {
        this(id, "", "");
    }

    public Record(int id, String title) {
        this(id, title, "");
    }

    public Record(int id, String title, String description) {
        this.id = id;
        this.title = title;
        this.description = description;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Override
    public int id() {
        return this.id;
    }

    @Override
    public String toString() {
        return String.format("(%d,%s)", id, title); //String.format("$e_{\\mathsf{id}=%d}$", id);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Record record = (Record) o;
        return id == record.id;
    }

}
